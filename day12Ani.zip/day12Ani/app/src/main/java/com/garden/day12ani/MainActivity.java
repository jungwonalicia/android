package com.garden.day12ani;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import com.garden.day12ani.R;

public class MainActivity extends AppCompatActivity {

    ImageView mImgView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        final Animation animTransRight = AnimationUtils.loadAnimation(
//                this,R.anim.right);
//                mImgView.startAnimation(animTransRight);


        mImgView = (ImageView) findViewById(R.id.imgTranslate);
        final Animation animTransRight = AnimationUtils.loadAnimation(
                this, R.anim.right);
        final Animation animTransLeft = AnimationUtils.loadAnimation(
                this, R.anim.left);
        final Animation animTransAlpha = AnimationUtils.loadAnimation(
                this, R.anim.alpha);
        final Animation animTransTwits = AnimationUtils.loadAnimation(
                this, R.anim.twits);


        Button btnRight = (Button) findViewById(R.id.btn_right);
        Button btnLeft = (Button) findViewById(R.id.btn_left);
        Button btnAlpha = (Button) findViewById(R.id.btn_alpha);
        Button btnCycle = (Button) findViewById(R.id.btn_twit);

        btnRight.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImgView.startAnimation(animTransRight);
            }
        });

        btnLeft.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImgView.startAnimation(animTransLeft);
            }
        });

        btnAlpha.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImgView.startAnimation(animTransAlpha);
            }
        });

        btnCycle.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                mImgView.startAnimation(animTransTwits);
            }
        });
    }
}


