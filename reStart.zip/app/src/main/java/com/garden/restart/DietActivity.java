package com.garden.restart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class DietActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet);

        //1. 처리할 버튼을 찾으세요.
        //컨트롤+스페이스바
        Button goStart = findViewById(R.id.goStart);

        //2. 버튼을 클릭했을 때 처리할 것을 셋팅
        goStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "첫 화면으로 돌아갑니다.", Toast.LENGTH_LONG).show();
                //3. 처리할 내용은 DietActivity를 시작
                Intent go = new Intent(getApplicationContext(), MainActivity.class);

//                2-2) intent부품 시작
                startActivity(go);

            }
        });









    }
}
