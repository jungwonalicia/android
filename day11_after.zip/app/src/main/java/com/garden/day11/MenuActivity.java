package com.garden.day11;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MenuActivity extends AppCompatActivity {
    ProgressDialog progressDialog;
    int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        final ProgressBar progressBar = findViewById(R.id.progressBar);
        int nowProgress = progressBar.getProgress();
        progressBar.setProgress(nowProgress - 10);

        TextView textView2 = findViewById(R.id.textView2);
        textView2.setText(progressBar.getProgress() + "%");

        Button button4 = findViewById(R.id.button4);


        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (flag == 0) {
                    progressDialog = new ProgressDialog(MenuActivity.this);
                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    progressDialog.setMessage("데이터 분석 중입니다.");
                    progressDialog.show();
                    flag = 1;
                } else {
                    progressDialog.dismiss();
                    flag = 0;
                }
            }
        });
    }
}
