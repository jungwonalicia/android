package com.garden.day10;

import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class ScrollViewActivity extends AppCompatActivity {
BitmapDrawable bitmap;
ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scroll_view);
        Resources res = getResources();
        bitmap = (BitmapDrawable)res.getDrawable(R.drawable.p1);
        imageView = findViewById(R.id.image);
        imageView.setImageDrawable(bitmap);
//        imageView.getLayoutParams().width = 2000;
//        imageView.getLayoutParams().height = 3000;


    }
}
