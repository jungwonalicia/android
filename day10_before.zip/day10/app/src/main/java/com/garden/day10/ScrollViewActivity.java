package com.garden.day10;

import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ScrollView;

public class ScrollViewActivity extends AppCompatActivity {

    ScrollView scrollView;
    ImageView imageView;
    BitmapDrawable bitmap, bitmap2; //이미지 파일 인식 객체
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scroll_view_layout);
        imageView = findViewById(R.id.imageView);
//        scrollView = findViewById(R.id.scrollView);
//        scrollView.setHorizontalScrollBarEnabled(true);

        Resources res = getResources();
        bitmap = (BitmapDrawable)res.getDrawable(R.drawable.p1);
        imageView.setImageDrawable(bitmap);
        imageView.getLayoutParams().width = 2000;
        imageView.getLayoutParams().height = 3000;

        button = findViewById(R.id.changeImg);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgChange();
            }
        });

    }

    public void imgChange(){
        Resources res = getResources();
        bitmap2 = (BitmapDrawable)res.getDrawable(R.drawable.p2);
        imageView.setImageDrawable(bitmap2);
        imageView.getLayoutParams().width = 2000;
        imageView.getLayoutParams().height = 3000;
    }
}
